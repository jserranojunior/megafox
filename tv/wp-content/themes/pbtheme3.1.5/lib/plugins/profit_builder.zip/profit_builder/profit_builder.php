<?php
/*
Plugin Name: Profit Builder
Plugin URI: http://www.clicko.me/joinbbhf/
Author URI: http://www.clicko.me/joinbbhf/
Description: Profit Builder is the Ultimate sIMplified LIVE Builder and Profit Generator for Wordpress, giving users an Amazing "All in One" toolbox and empowering websites.
Author: Sean Donahoe
Version: 1.8.6
*/

if (!function_exists('add_action')) {
	header('Status: 404 Forbidden');
	header('HTTP/1.1 404 Forbidden');
	exit;
}

if (defined('WP_DEBUG') && WP_DEBUG) {
  error_reporting(-1);
} else {
  error_reporting(0);
}

define('IMSCPB_FILE', __FILE__);
if (version_compare(phpversion(), '5.3', '>=')) {
	global $pbuilder;
	if (!class_exists("ProfitBuilder")) {
		require_once dirname(__FILE__) . '/profit_builder_class.php';
	}
} else {
	if (is_admin()) {
		add_action('admin_notices', 'imscpb_DashboardAlert');
	}
}

function imscpb_DashboardAlert() {
	echo "
    <div class='updated fade'>
        <p style='font-size:18px;'>
            <img src='http://d1ug6aqcpxo8y6.cloudfront.net/ui/images/icons/22/warning.png' style='margin-bottom:-2px;'>&nbsp;&nbsp;
            <strong>WARNING</strong> - ProfitBuilder requires a minimum of PHP 5.3. We have detected your PHP version (" . phpversion() . ") is old and insecure. Please ask your host to upgrade your server to a minimum of 5.3.
        </p>
    </div>";
}